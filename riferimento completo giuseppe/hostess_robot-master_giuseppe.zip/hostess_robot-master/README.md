# hostess_robot
ROS metapackage containing a OpenNI-derived skeleton tracker, with separate launch files to run the xtion/kinect device and skeleton tracker on a robot and perform point cloud reconstruction (and later on face recognition) on a remote workstation.
